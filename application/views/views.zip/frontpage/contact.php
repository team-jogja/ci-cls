<section class="view" id="contact1">
        <div class="ful-bg1 d-flex align-items-center white-text">
          <div class="container">

            <div class="row wow fadeInUp align-items-center" data-wow-delay=".3s" style="place-content: center">
                    
                <div class="col-lg-8 col-xl-6 pb-3 ">
                  <p class="mt-3 white-text left-text font-bold" style="font-size: -webkit-xxx-large;"> ENQUIRY </p>
                  <img class="mb-3" mb-3 src="<?= base_url('assets/img/home/Rectangle 93.png'); ?>">
                    <div class="row mb-1">
                      <div class="col-8 mr-1" style="font-size : medium"><p>
                      <div class="row mb-1 ml-2"><i class="fa fa-phone fa-2x"></i>
                      <div class="col-10 mr-1" style="font-size : medium"><p>
                          (021)22686277 / (021)22686511 
                        </p></div></div>

                      <div class="row mb-1 ml-2"><i class="fa fa-envelope fa-2x"></i>
                      <div class="col-10 mr-1" style="font-size : medium"><p>
                          info@cls-indo.com  
                        </p></div></div>
                      
                        </p></div></div>
                </div>
                <div class="col-lg-8 col-xl-6 pb-3 right-text1 jumbotron">
                    <div class="col-lg-12 pb-2 ">
                    <form>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="md-form">
                            <input class="form-control" id="name" type="text" name="name" required="required"/>
                            <label for="name">Full Name</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="md-form">
                            <input class="form-control" id="email" type="text" name="_replyto" required="required"/>
                            <label for="email">Phone Number</label>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="md-form">
                            <input class="form-control" id="name" type="text" name="name" required="required"/>
                            <label for="name">Email</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="md-form">
                            <input class="form-control" id="email" type="text" name="_replyto" required="required"/>
                            <label for="email">Job Tittle</label>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="md-form">
                            <input class="form-control" id="name" type="text" name="name" required="required"/>
                            <label for="name">Company Name</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="md-form">
                            <input class="form-control" id="email" type="text" name="_replyto" required="required"/>
                            <label for="email">Country</label>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-12">
                        <div class="md-form">
                          <textarea class="md-textarea" id="message" name="message" required="required"></textarea>
                          <label for="message">Your message</label>
                        </div>
                      </div>
                      <div class="center-on-small-only mb-4">
                        <button class="btn btn-indigo ml-0" type="submit" style="border-radius: 25px;"></i> Submit</button>
                      </div>
                    </form>
                    </div>
                </div>

          </div>

          </div>
        </div>
      </section>
    </header>
    
</div>