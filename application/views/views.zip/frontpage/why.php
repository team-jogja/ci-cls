<section class="view" id="why1">
        <div class="ful-bg1 d-flex align-items-center">
          <div class="container">

          <div class="row wow fadeInUp align-items-center" data-wow-delay=".3s">
                <p class="mt-3 mb-5 white-text left-text font-bold" style="font-size:  40px;">
                  EXPERIENCE BOTH TOP AND BOTTOOM LINES </br>
                  BENEFITS WITH US
                </p></br>
              <div class="col-lg-6 col-xl-5 pb-3 mt-5">
              <img mb-3 src="<?= base_url('assets/img/home/Rectangle 93.png'); ?>">
                  <p class="justify-text mt-3 white-text font-bold" style="font-size: large;" >
                  As a business partner, you will experience both top and bottom lines benefits 
                  </p>
              </div>

              <div class="col-lg-8 col-xl-6 pb-3">
                  <p class="col-lg12 pb-5">
                      <!-- biar kkan kosong -->
                  </p>
              </div>

          </div>

          </div>
        </div>
      </section>
    </header>
    <section class="view lighten-4" id="why2">
  <div class="container ful-bg1 white-text">
    <div class="row wow fadeInUp align-items-center" data-wow-delay=".3s" style="place-content: center">
         
        
        <div class="col-lg-8 col-xl-6 pb-3 pt-5 ">
            <h4 class=" h4-responsive font-bold">TOP LINE</h4>
             <div class="row mb-1">
               <div class="col-8 mr-1" style="font-size : x-small"><p>
               <div class="row mb-1 ml-2"><i class="fa fa-circle"></i>
                <div class="col-10 mr-1" style="font-size : xx-small"><p>
                  Free Internal resources to focus on core business 
                </p></div></div>
               <div class="row mb-1 ml-2"><i class="fa fa-circle"></i>
                <div class="col-10 mr-1" style="font-size : xx-small"><p>
                  Shorten implementation cycles
                </p></div></div>
               <div class="row mb-1 ml-2"><i class="fa fa-circle"></i>
                <div class="col-10 mr-1" style="font-size : xx-small"><p>
                  Improved total IT performance 
                </p></div></div>
               <div class="row mb-1 ml-2"><i class="fa fa-circle"></i>
                <div class="col-10 mr-1" style="font-size : xx-small"><p>
                  Expand operations without investing in IT infrastructure 
                </p></div></div>
                </p></div></div>
                
        </div>
        <div class="col-lg-8 col-xl-6 pb-3 right-text1">
            <p class="col-lg-12 pb-2 ">
                <!-- biarkon kosong -->
            </p>
        </div>

  </div>
</section>
<section class="view lighten-4" id="why3">
  <div class="container ful-bg1 white-text">
    <div class="row wow fadeInUp align-items-center" data-wow-delay=".3s" style="place-content: center">
         
        <div class="col-lg-8 col-xl-6 pb-3 right-text1">
            <p class="col-lg-12 pb-2 ">
                <!-- biarkon kosong -->
            </p>
        </div>
        <div class="col-lg-8 col-xl-6 pb-3 ">
            <h4 class=" h4-responsive font-bold">BOTTOM LINE</h4>
             <div class="row mb-1">
               <div class="col-8 mr-1" style="font-size : x-small"><p>
               <div class="row mb-1 ml-2"><i class="fa fa-circle"></i>
                <div class="col-10 mr-1" style="font-size : xx-small"><p>
                  No Big Capital Investments 
                </p></div></div>
               <div class="row mb-1 ml-2"><i class="fa fa-circle"></i>
                <div class="col-10 mr-1" style="font-size : xx-small"><p>
                Lower cost of entry 
                </p></div></div>
               <div class="row mb-1 ml-2"><i class="fa fa-circle"></i>
                <div class="col-10 mr-1" style="font-size : xx-small"><p>
                More predictable IT support costs  
                </p></div></div>
               <div class="row mb-1 ml-2"><i class="fa fa-circle"></i>
                <div class="col-10 mr-1" style="font-size : xx-small"><p>
                Centralized point for support, training and management funtions
                </p></div></div>
               <div class="row mb-1 ml-2"><i class="fa fa-circle"></i>
                <div class="col-10 mr-1" style="font-size : xx-small"><p>
                Reduce IT investment risk in volatile environment 
                </p></div></div>
               <div class="row mb-1 ml-2"><i class="fa fa-circle"></i>
                <div class="col-10 mr-1" style="font-size : xx-small"><p>
                Reliable Resolutions 
                </p></div></div>
                <div  class="wow fadeInUp mb-5"><a style="border-radius: 25px;" class="btn btn-outline-light font-bold ml-0" href="" target="_blank">Talk to Us</a></div>
                </p></div></div>
        </div>
        

  </div>
</section>

</div>